/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Bank;
//import Business.Organization.CareTakerOrganization;
import Business.Organization.OrganizationDirectory;
import Business.WorkQueue.WorkRequest;

/**
 *
 * @author sagar
 */
public class Banking extends WorkRequest{
    private String BankName;
    private Double AvailFunds;
    private Double EmergencyContactNumber;
    private Double FundsApproved;
    private String BranchName;    

    public String getBankName() {
        return BankName;
    }

    public void setBankName(String BankName) {
        this.BankName = BankName;
    }

    public Double getAvailFunds() {
        return AvailFunds;
    }

    public void setAvailFunds(Double AvailFunds) {
        this.AvailFunds = AvailFunds;
    }

    public Double getEmergencyContactNumber() {
        return EmergencyContactNumber;
    }

    public void setEmergencyContactNumber(Double EmergencyContactNumber) {
        this.EmergencyContactNumber = EmergencyContactNumber;
    }

    public Double getFundsApproved() {
        return FundsApproved;
    }

    public void setFundsApproved(Double FundsApproved) {
        this.FundsApproved = FundsApproved;
    }

    public String getBranchName() {
        return BranchName;
    }

    public void setBranchName(String BranchName) {
        this.BranchName = BranchName;
    }
    
    @Override
    public String toString() {
        return BankName;
    }
}
